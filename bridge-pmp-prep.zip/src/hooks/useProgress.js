import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { DOMAINS } from '@/lib/domainData';

export function useProgress() {
  const { data: quizResults = [], isLoading } = useQuery({
    queryKey: ['quizResults'],
    queryFn: () => base44.entities.QuizResult.list('-created_date', 500),
    initialData: [],
  });

  // Calculate per-domain progress (average score of all quizzes in that domain)
  const domainProgress = {};
  const availableDomains = DOMAINS.filter(d => d.available);

  availableDomains.forEach(domain => {
    const domainQuizzes = quizResults.filter(q => q.domain === domain.id);
    if (domainQuizzes.length === 0) {
      domainProgress[domain.id] = 0;
    } else {
      const avgScore = domainQuizzes.reduce((sum, q) => sum + (q.score || 0), 0) / domainQuizzes.length;
      domainProgress[domain.id] = avgScore;
    }
  });

  // Overall readiness = weighted average based on exam weight
  const totalWeight = availableDomains.reduce((sum, d) => sum + d.examWeight, 0);
  const overallReadiness = totalWeight > 0
    ? availableDomains.reduce((sum, d) => sum + (domainProgress[d.id] || 0) * d.examWeight, 0) / totalWeight
    : 0;

  return {
    domainProgress,
    overallReadiness,
    quizResults,
    isLoading,
    totalQuizzes: quizResults.length,
  };
}