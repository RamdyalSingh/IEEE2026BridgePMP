import React from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '@/lib/AuthContext';
import { DOMAINS } from '@/lib/domainData';
import { useProgress } from '@/hooks/useProgress';
import DomainCard from '@/components/dashboard/DomainCard';
import ReadinessMeter from '@/components/dashboard/ReadinessMeter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Target, TrendingUp, Info } from 'lucide-react';
import TheoryLibrary from '@/components/theory/TheoryLibrary';

export default function Dashboard() {
  const { user } = useAuth();
  const { domainProgress, overallReadiness, totalQuizzes, isLoading } = useProgress();

  const availableDomains = DOMAINS.filter(d => d.available);
  const futureDomains = DOMAINS.filter(d => !d.available);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Welcome */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-foreground font-inter">
          Welcome back{user?.full_name ? `, ${user.full_name.split(' ')[0]}` : ''} 👋
        </h1>
        <p className="text-muted-foreground mt-1">Track your PMP exam preparation progress</p>
      </motion.div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Left: Domains */}
        <div className="flex-1 min-w-0">
          {/* Stats Row */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <StatsCard icon={BookOpen} label="Quizzes Taken" value={totalQuizzes} />
            <StatsCard icon={Target} label="Domains Started" value={availableDomains.filter(d => (domainProgress[d.id] || 0) > 0).length} />
            <StatsCard icon={TrendingUp} label="Avg Score" value={`${Math.round(overallReadiness)}%`} />
          </div>

          {/* Domain Cards */}
          <div className="space-y-3">
            <h2 className="text-lg font-semibold text-foreground font-inter mb-4">PMP Domains</h2>
            {availableDomains.map((domain, i) => (
              <DomainCard
                key={domain.id}
                domain={domain}
                progress={domainProgress[domain.id] || 0}
                index={i}
              />
            ))}
          </div>

          {/* Knowledge Vault */}
          <div className="mt-6">
            <TheoryLibrary />
          </div>

          {/* Coming Soon: AI + Sustainability — compact banner */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-4 flex items-center gap-3 p-3 rounded-xl bg-muted/50 border border-dashed border-border"
          >
            <Info className="w-4 h-4 text-muted-foreground shrink-0" />
            <p className="text-xs text-muted-foreground">
              <span className="font-semibold text-foreground">Coming after July 8th, 2026:</span>{' '}
              AI & Sustainability domains — new additions to the PMP exam by PMI.
            </p>
          </motion.div>
        </div>

        {/* Right: Readiness Meter */}
        <div className="lg:w-80 shrink-0">
          <Card className="shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-inter flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                Exam Readiness
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ReadinessMeter percentage={overallReadiness} />

              {/* Domain breakdown */}
              <div className="mt-6 space-y-3">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Domain Breakdown</p>
                {availableDomains.map(domain => (
                  <div key={domain.id} className="flex items-center justify-between text-sm">
                    <div>
                      <span className="text-foreground font-medium">{domain.name}</span>
                      <span className="ml-1.5 text-xs text-muted-foreground">({domain.examWeight}% of exam)</span>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {Math.round(domainProgress[domain.id] || 0)}%
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function StatsCard({ icon: Icon, label, value }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-card rounded-xl border border-border p-4"
    >
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-accent flex items-center justify-center">
          <Icon className="w-4 h-4 text-primary" />
        </div>
        <div>
          <p className="text-xl font-bold text-foreground font-inter">{value}</p>
          <p className="text-xs text-muted-foreground">{label}</p>
        </div>
      </div>
    </motion.div>
  );
}