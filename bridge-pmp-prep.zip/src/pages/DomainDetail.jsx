import React from 'react';
import { Link, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { DOMAINS } from '@/lib/domainData';
import { useProgress } from '@/hooks/useProgress';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, Play, BookOpen, CheckCircle2, Circle } from 'lucide-react';

export default function DomainDetail() {
  const { domainId } = useParams();
  const { domainProgress, quizResults } = useProgress();

  const domain = DOMAINS.find(d => d.id === domainId);

  if (!domain || !domain.available) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-foreground">Domain not found</h2>
        <Link to="/">
          <Button className="mt-4">Back to Dashboard</Button>
        </Link>
      </div>
    );
  }

  const progress = domainProgress[domain.id] || 0;
  const domainQuizzes = quizResults.filter(q => q.domain === domain.id);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Back + Title */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6">
          <ArrowLeft className="w-4 h-4" />
          <span className="text-sm font-medium">Back to Dashboard</span>
        </Link>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-4">
            <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${domain.color} flex items-center justify-center shadow-lg`}>
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground font-inter">{domain.name}</h1>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="secondary">{domain.examWeight}% of exam</Badge>
                <Badge variant="outline">{Math.round(progress)}% mastered</Badge>
              </div>
            </div>
          </div>

          <Link to={`/quiz?domain=${domain.id}`}>
            <Button size="lg" className="gap-2 bg-gradient-to-r from-primary to-violet-600 hover:opacity-90 shadow-md shadow-primary/20">
              <Play className="w-4 h-4" />
              Take Quiz
            </Button>
          </Link>
        </div>
      </motion.div>

      {/* Progress */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium text-foreground">Your Progress</span>
              <span className="text-sm font-bold text-primary">{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-3" />
            <p className="text-xs text-muted-foreground mt-2">
              Based on {domainQuizzes.length} quiz{domainQuizzes.length !== 1 ? 'zes' : ''} taken
            </p>
          </CardContent>
        </Card>
      </motion.div>

      {/* Description */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-lg font-inter">About this Domain</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground leading-relaxed">{domain.description}</p>
          </CardContent>
        </Card>
      </motion.div>

      {/* Subtopics */}
      {domain.subtopics && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-inter">Key Topics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {domain.subtopics.map((topic, i) => (
                  <motion.div
                    key={topic}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.25 + i * 0.03 }}
                    className="flex items-center gap-3 p-3 rounded-xl bg-muted/40 hover:bg-muted/70 transition-colors"
                  >
                    {progress > (i / domain.subtopics.length) * 100 ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                    ) : (
                      <Circle className="w-5 h-5 text-muted-foreground shrink-0" />
                    )}
                    <span className="text-sm font-medium text-foreground">{topic}</span>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Recent Quizzes */}
      {domainQuizzes.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card className="mt-8">
            <CardHeader>
              <CardTitle className="text-lg font-inter">Recent Quiz Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {domainQuizzes.slice(0, 5).map((quiz, i) => (
                  <div key={quiz.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                    <span className="text-sm text-muted-foreground">
                      {quiz.correct_answers}/{quiz.total_questions} correct
                    </span>
                    <Badge variant={quiz.score >= 70 ? 'default' : 'secondary'}>
                      {Math.round(quiz.score)}%
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}