import React, { useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { DOMAINS } from '@/lib/domainData';
import { MCQ_BANK } from '@/lib/mcqBank';
import { useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, Loader2, CheckCircle2, XCircle, RotateCcw, Home, Shuffle, BookOpen } from 'lucide-react';

const QUIZ_LENGTH = 10;

function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// Shuffle the options of a question and update correct_index accordingly
function shuffleOptions(q) {
  const correctText = q.options[q.correct_index];
  const shuffled = shuffleArray([...q.options]);
  return {
    ...q,
    options: shuffled,
    correct_index: shuffled.indexOf(correctText),
  };
}

export default function Quiz() {
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const preSelectedDomain = urlParams.get('domain');

  const [selectedDomain, setSelectedDomain] = useState(preSelectedDomain || null);
  const [useAI, setUseAI] = useState(false);
  const [questions, setQuestions] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [finalScore, setFinalScore] = useState(0);

  const availableDomains = DOMAINS.filter(d => d.available);

  const startQuiz = useCallback(async (domainId, aiMode) => {
    setSelectedDomain(domainId);
    setUseAI(aiMode);
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setIsAnswered(false);
    setScore(0);
    setIsFinished(false);
    setFinalScore(0);

    if (aiMode) {
      setIsGenerating(true);
      const domain = DOMAINS.find(d => d.id === domainId);
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate ${QUIZ_LENGTH} PMP exam practice questions for the "${domain.name}" domain based on PMBOK 8th Edition. Each must be a realistic scenario-based multiple choice question with 4 options (A-D) and exactly one correct answer. Cover different subtopics within: ${domain.subtopics ? domain.subtopics.join(', ') : domain.name}`,
        response_json_schema: {
          type: "object",
          properties: {
            questions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  question: { type: "string" },
                  options: { type: "array", items: { type: "string" } },
                  correct_index: { type: "number" },
                  explanation: { type: "string" }
                }
              }
            }
          }
        }
      });
      setQuestions((result.questions || []).map(shuffleOptions));
      setIsGenerating(false);
    } else {
      // Use MCQ bank — randomly pick QUIZ_LENGTH questions for the domain
      const bank = MCQ_BANK[domainId] || [];
      const picked = shuffleArray(bank).slice(0, Math.min(QUIZ_LENGTH, bank.length)).map(shuffleOptions);
      setQuestions(picked);
    }
  }, []);

  const handleAnswer = (index) => {
    if (isAnswered) return;
    setSelectedAnswer(index);
    setIsAnswered(true);
    if (index === questions[currentIndex].correct_index) {
      setScore(prev => prev + 1);
    }
  };

  const handleNext = async () => {
    const isLastQuestion = currentIndex === questions.length - 1;

    if (!isLastQuestion) {
      setCurrentIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setIsAnswered(false);
    } else {
      const currentCorrect = selectedAnswer === questions[currentIndex].correct_index ? 1 : 0;
      const totalCorrect = score + currentCorrect;
      const percentage = (totalCorrect / questions.length) * 100;
      setFinalScore(percentage);
      setIsFinished(true);

      await base44.entities.QuizResult.create({
        domain: selectedDomain,
        score: percentage,
        total_questions: questions.length,
        correct_answers: totalCorrect,
      });
      queryClient.invalidateQueries({ queryKey: ['quizResults'] });
    }
  };

  const resetQuiz = () => {
    setQuestions([]);
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setIsAnswered(false);
    setScore(0);
    setIsFinished(false);
    setFinalScore(0);
    setSelectedDomain(preSelectedDomain || null);
  };

  // --- Domain Selection ---
  if (!selectedDomain || questions.length === 0 && !isGenerating && !isFinished) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-8">
        <Link to="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6">
          <ArrowLeft className="w-4 h-4" />
          <span className="text-sm font-medium">Back to Dashboard</span>
        </Link>
        <h1 className="text-2xl font-bold text-foreground font-inter mb-2">Choose a Domain</h1>
        <p className="text-muted-foreground text-sm mb-6">Select a domain and quiz mode to begin practicing</p>
        <div className="space-y-4">
          {availableDomains.map(domain => (
            <motion.div
              key={domain.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-2xl border border-border bg-card overflow-hidden"
            >
              <div className="flex items-center gap-4 p-5">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${domain.color} flex items-center justify-center shrink-0`}>
                  <span className="text-white font-bold text-sm">{domain.name[0]}</span>
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-foreground">{domain.name}</p>
                  <p className="text-sm text-muted-foreground">{domain.examWeight}% of exam · {(MCQ_BANK[domain.id] || []).length} questions in bank</p>
                </div>
              </div>
              <div className="flex border-t border-border">
                <button
                  onClick={() => startQuiz(domain.id, false)}
                  className="flex-1 flex items-center justify-center gap-2 py-3 text-sm font-medium text-foreground hover:bg-muted/50 transition-colors border-r border-border"
                >
                  <BookOpen className="w-4 h-4 text-primary" />
                  MCQ Bank ({Math.min(QUIZ_LENGTH, (MCQ_BANK[domain.id] || []).length)} Qs)
                </button>
                <button
                  onClick={() => startQuiz(domain.id, true)}
                  className="flex-1 flex items-center justify-center gap-2 py-3 text-sm font-medium text-foreground hover:bg-muted/50 transition-colors"
                >
                  <Shuffle className="w-4 h-4 text-violet-500" />
                  AI Generated
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    );
  }

  // --- Loading ---
  if (isGenerating) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <Loader2 className="w-10 h-10 text-primary animate-spin mx-auto mb-4" />
        <p className="text-lg font-medium text-foreground font-inter">Generating your quiz...</p>
        <p className="text-sm text-muted-foreground mt-1">AI is crafting personalized PMP questions</p>
      </div>
    );
  }

  // --- Results ---
  if (isFinished) {
    const pct = finalScore;
    const correctCount = Math.round((pct / 100) * questions.length);
    return (
      <div className="max-w-2xl mx-auto px-4 py-8">
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
          <Card className="text-center">
            <CardContent className="p-10">
              <div className={`w-20 h-20 rounded-full mx-auto mb-6 flex items-center justify-center ${
                pct >= 70 ? 'bg-emerald-100' : pct >= 40 ? 'bg-amber-100' : 'bg-red-100'
              }`}>
                {pct >= 70
                  ? <CheckCircle2 className="w-10 h-10 text-emerald-600" />
                  : <XCircle className="w-10 h-10 text-amber-600" />
                }
              </div>
              <h2 className="text-2xl font-bold text-foreground font-inter mb-2">Quiz Complete!</h2>
              <p className={`text-4xl font-bold mb-2 ${pct >= 70 ? 'text-emerald-600' : pct >= 40 ? 'text-amber-600' : 'text-red-600'}`}>
                {Math.round(pct)}%
              </p>
              <p className="text-muted-foreground mb-2">
                You got {correctCount} out of {questions.length} questions correct
              </p>
              <p className="text-sm text-muted-foreground mb-8">
                {pct >= 70 ? '🎉 Excellent! Keep it up!' : pct >= 40 ? '📚 Good effort — review and try again!' : '💪 Keep studying — you\'ve got this!'}
              </p>
              <div className="flex gap-3 justify-center flex-wrap">
                <Button onClick={resetQuiz} variant="outline" className="gap-2">
                  <RotateCcw className="w-4 h-4" />
                  Try Again
                </Button>
                <Link to="/">
                  <Button className="gap-2">
                    <Home className="w-4 h-4" />
                    Dashboard
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  // --- Active Quiz ---
  if (questions.length === 0) return null;

  const currentQ = questions[currentIndex];
  const domain = DOMAINS.find(d => d.id === selectedDomain);

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-sm">{domain?.name}</Badge>
          {useAI && <Badge variant="outline" className="text-xs text-violet-600 border-violet-300">AI Generated</Badge>}
        </div>
        <span className="text-sm text-muted-foreground font-medium">
          {currentIndex + 1} / {questions.length}
        </span>
      </div>

      <Progress value={((currentIndex + 1) / questions.length) * 100} className="h-1.5 mb-8" />

      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.2 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-inter leading-relaxed font-medium">
                {currentQ.question}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {currentQ.options.map((option, i) => {
                const isCorrect = i === currentQ.correct_index;
                const isSelected = i === selectedAnswer;
                let cls = 'border-border hover:border-primary/40 hover:bg-accent/50 cursor-pointer';

                if (isAnswered) {
                  if (isCorrect) cls = 'border-emerald-400 bg-emerald-50';
                  else if (isSelected) cls = 'border-red-400 bg-red-50';
                  else cls = 'border-border opacity-40 cursor-default';
                }

                return (
                  <button
                    key={i}
                    onClick={() => handleAnswer(i)}
                    disabled={isAnswered}
                    className={`w-full text-left p-4 rounded-xl border-2 transition-all ${cls}`}
                  >
                    <div className="flex items-start gap-3">
                      <span className="shrink-0 w-7 h-7 rounded-full bg-muted flex items-center justify-center text-xs font-bold text-muted-foreground">
                        {String.fromCharCode(65 + i)}
                      </span>
                      <span className="text-sm font-medium text-foreground flex-1">{option}</span>
                      {isAnswered && isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />}
                      {isAnswered && isSelected && !isCorrect && <XCircle className="w-5 h-5 text-red-500 shrink-0" />}
                    </div>
                  </button>
                );
              })}

              {isAnswered && currentQ.explanation && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-2 p-4 rounded-xl bg-accent/40 border border-border"
                >
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    <span className="font-semibold text-foreground">💡 Explanation: </span>
                    {currentQ.explanation}
                  </p>
                </motion.div>
              )}

              {isAnswered && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="pt-2">
                  <Button onClick={handleNext} className="w-full" size="lg">
                    {currentIndex < questions.length - 1 ? 'Next Question →' : 'See Results'}
                  </Button>
                </motion.div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}