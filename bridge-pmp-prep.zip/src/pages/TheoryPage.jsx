import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { THEORY_CONTENT } from '@/lib/theoryContent';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, ChevronDown, ChevronUp, BookOpen, ChevronRight } from 'lucide-react';
import SubsectionModal from '@/components/theory/SubsectionModal';

const DOMAIN_STYLES = {
  people: {
    gradient: 'from-emerald-500 to-teal-600',
    accent: 'text-emerald-600',
  },
  process: {
    gradient: 'from-indigo-500 to-violet-600',
    accent: 'text-indigo-600',
  },
  business_environment: {
    gradient: 'from-amber-500 to-orange-600',
    accent: 'text-amber-600',
  },
};

function SectionCard({ section, style, defaultOpen = false, onSubsectionClick }) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="border border-border rounded-2xl overflow-hidden mb-4 bg-card shadow-sm"
    >
      {/* Section header */}
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-4 p-5 text-left hover:bg-muted/30 transition-colors"
      >
        <div className={`shrink-0 w-10 h-10 rounded-xl bg-gradient-to-br ${style.gradient} flex items-center justify-center`}>
          <span className="text-white text-xs font-bold">{section.number}</span>
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-foreground leading-snug">{section.title}</p>
          <p className="text-xs text-muted-foreground mt-0.5">{section.summary}</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Badge variant="outline" className="text-xs hidden sm:flex">{section.subsections.length} subtopics</Badge>
          {open
            ? <ChevronUp className="w-5 h-5 text-muted-foreground" />
            : <ChevronDown className="w-5 h-5 text-muted-foreground" />
          }
        </div>
      </button>

      {/* Subsections list */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.22 }}
            className="overflow-hidden"
          >
            <div className="border-t border-border divide-y divide-border/60">
              {section.subsections.map((sub) => (
                <button
                  key={sub.id}
                  onClick={() => onSubsectionClick(sub)}
                  className="w-full flex items-center gap-3 px-5 py-4 text-left hover:bg-accent/40 transition-colors group"
                >
                  <span className={`text-xs font-bold ${style.accent} w-10 shrink-0`}>{sub.number}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground group-hover:text-primary transition-colors leading-snug">
                      {sub.title}
                    </p>
                    <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">
                      {sub.body.split('\n')[0].replace(/\*\*/g, '').substring(0, 80)}...
                    </p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors shrink-0" />
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function TheoryPage() {
  const { domainId } = useParams();
  const content = THEORY_CONTENT[domainId];
  const style = DOMAIN_STYLES[domainId] || DOMAIN_STYLES.people;
  const [selectedSubsection, setSelectedSubsection] = useState(null);

  if (!content) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-12 text-center">
        <p className="text-muted-foreground">Domain not found.</p>
        <Link to="/" className="text-primary text-sm mt-4 inline-block">← Back to Dashboard</Link>
      </div>
    );
  }

  const totalSubsections = content.sections.reduce((acc, s) => acc + s.subsections.length, 0);

  return (
    <>
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        {/* Back */}
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6 text-sm font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Dashboard
        </Link>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`rounded-2xl bg-gradient-to-br ${style.gradient} p-6 mb-8 text-white shadow-lg`}
        >
          <div className="flex items-start justify-between flex-wrap gap-3">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <BookOpen className="w-5 h-5 text-white/80" />
                <span className="text-white/80 text-sm font-medium">Knowledge Vault</span>
                <Badge className="bg-white/20 text-white border-white/30 text-xs">PMBOK 8th Ed.</Badge>
              </div>
              <h1 className="text-2xl font-bold font-inter leading-tight">{content.title}</h1>
              <p className="text-white/80 text-sm mt-1">{content.examWeight}% of PMP Exam</p>
            </div>
            <div className="text-right shrink-0">
              <p className="text-white/70 text-xs font-medium uppercase tracking-wider">Subtopics</p>
              <p className="text-white text-3xl font-bold">{totalSubsections}</p>
            </div>
          </div>
          <p className="text-white/90 text-sm mt-4 leading-relaxed">{content.intro}</p>
          <p className="text-white/70 text-xs mt-3">Click any subtopic to open its full content</p>
        </motion.div>

        {/* Table of Contents */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="bg-card rounded-2xl border border-border p-4 mb-6"
        >
          <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3">Sections</p>
          <div className="space-y-1">
            {content.sections.map((section) => (
              <div key={section.id} className="flex items-center gap-2 text-sm py-1.5 px-2 rounded-lg">
                <span className={`text-xs font-bold ${style.accent} w-8 shrink-0`}>{section.number}</span>
                <span className="text-foreground flex-1">{section.title}</span>
                <span className="text-xs text-muted-foreground">{section.subsections.length}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Sections */}
        <div>
          {content.sections.map((section, i) => (
            <div key={section.id} id={section.id}>
              <SectionCard
                section={section}
                style={style}
                defaultOpen={i === 0}
                onSubsectionClick={setSelectedSubsection}
              />
            </div>
          ))}
        </div>

        {/* Bottom nav */}
        <div className="mt-8 pt-6 border-t border-border flex justify-between items-center flex-wrap gap-3">
          <Link to="/" className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1">
            <ArrowLeft className="w-4 h-4" /> Dashboard
          </Link>
          <Link
            to={`/quiz?domain=${domainId}`}
            className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-br ${style.gradient} text-white text-sm font-semibold shadow-md hover:opacity-90 transition-opacity`}
          >
            Practice Quiz →
          </Link>
        </div>
      </div>

      {/* Full-screen modal */}
      {selectedSubsection && (
        <SubsectionModal
          subsection={selectedSubsection}
          domainStyle={style}
          onClose={() => setSelectedSubsection(null)}
        />
      )}
    </>
  );
}