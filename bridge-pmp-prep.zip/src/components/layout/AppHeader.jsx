import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Search, Play, User, LogOut, Home } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function AppHeader() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-card/80 backdrop-blur-xl border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-violet-600 flex items-center justify-center">
              <span className="text-white font-bold text-sm">B</span>
            </div>
            <span className="font-inter font-bold text-xl text-foreground tracking-tight">
              Bridge<span className="text-primary">PMP</span>
            </span>
          </Link>

          {/* Center: Search */}
          <form onSubmit={handleSearch} className="hidden md:flex items-center flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search domains, topics..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-muted/50 border-transparent focus:border-primary/30 focus:bg-card"
              />
            </div>
          </form>

          {/* Right Side */}
          <div className="flex items-center gap-3">
            <Link to="/">
              <Button variant="ghost" size="sm" className="hidden sm:flex gap-2">
                <Home className="w-4 h-4" />
                Home
              </Button>
            </Link>

            <Link to="/quiz">
              <Button size="sm" className="gap-2 bg-gradient-to-r from-primary to-violet-600 hover:opacity-90 shadow-md shadow-primary/20">
                <Play className="w-4 h-4" />
                Take Quiz
              </Button>
            </Link>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 pl-3 pr-1 py-1 rounded-full bg-muted/60 hover:bg-muted transition-colors">
                  <span className="text-sm font-medium text-foreground hidden sm:block">
                    {user?.full_name ? `Welcome, ${user.full_name.split(' ')[0]}` : 'Welcome'}
                  </span>
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-violet-600 flex items-center justify-center">
                    <User className="w-4 h-4 text-white" />
                  </div>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem onClick={() => base44.auth.logout()}>
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
}