import React from 'react';
import { Outlet } from 'react-router-dom';
import AppHeader from './AppHeader';

export default function AppLayout() {
  return (
    <div className="min-h-screen bg-background font-inter">
      <AppHeader />
      <main>
        <Outlet />
      </main>
    </div>
  );
}