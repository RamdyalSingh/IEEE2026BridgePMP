import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Settings, Users, Building2, Brain, Leaf, ChevronRight, Lock } from 'lucide-react';

const iconMap = { Settings, Users, Building2, Brain, Leaf };

export default function DomainCard({ domain, progress = 0, index = 0 }) {
  const Icon = iconMap[domain.icon] || Settings;
  const isLocked = !domain.available;

  const content = (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08, duration: 0.4 }}
      className={`group relative rounded-2xl border bg-card p-5 transition-all duration-300 ${
        isLocked
          ? 'opacity-60 cursor-default border-dashed border-border'
          : 'hover:shadow-lg hover:shadow-primary/5 hover:-translate-y-0.5 cursor-pointer border-border hover:border-primary/20'
      }`}
    >
      <div className="flex items-center gap-4">
        {/* Icon */}
        <div className={`shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br ${domain.color} flex items-center justify-center shadow-md`}>
          {isLocked ? (
            <Lock className="w-5 h-5 text-white" />
          ) : (
            <Icon className="w-5 h-5 text-white" />
          )}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-1">
            <h3 className="font-semibold text-foreground text-lg font-inter">{domain.name}</h3>
            <div className="flex items-center gap-2">

              {!isLocked && (
                <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
              )}
            </div>
          </div>

          {isLocked ? (
            <p className="text-sm text-muted-foreground italic">Coming after July 8th, 2026</p>
          ) : (
            <div className="flex items-center gap-3">
              <Progress value={progress} className="flex-1 h-2" />
              <span className="text-sm font-medium text-muted-foreground whitespace-nowrap">
                {Math.round(progress)}% completed
              </span>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );

  if (isLocked) return content;

  return (
    <Link to={`/theory/${domain.id}`}>
      {content}
    </Link>
  );
}