import React from 'react';
import { motion } from 'framer-motion';

export default function ReadinessMeter({ percentage = 0 }) {
  // Clamp between 0-100
  const value = Math.min(100, Math.max(0, percentage));
  
  // Map percentage to angle: 0% = -90deg (left), 100% = 90deg (right)
  const needleAngle = -90 + (value / 100) * 180;

  const getLabel = () => {
    if (value <= 40) return { text: 'Not Ready', color: 'text-red-500' };
    if (value <= 70) return { text: 'Needs Practice', color: 'text-amber-500' };
    return { text: 'Ready!', color: 'text-emerald-500' };
  };

  const label = getLabel();

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-64" style={{ height: '160px' }}>
        {/* SVG Gauge — extra height so labels below arc are visible */}
        <svg viewBox="0 0 200 130" className="w-full h-full">
          {/* Background arc */}
          <path
            d="M 20 100 A 80 80 0 0 1 180 100"
            fill="none"
            stroke="hsl(var(--muted))"
            strokeWidth="16"
            strokeLinecap="round"
          />
          {/* Red zone (0-40%) */}
          <path
            d="M 20 100 A 80 80 0 0 1 55.36 33.74"
            fill="none"
            stroke="#ef4444"
            strokeWidth="16"
            strokeLinecap="round"
            opacity="0.8"
          />
          {/* Yellow zone (40-70%) */}
          <path
            d="M 55.36 33.74 A 80 80 0 0 1 126.18 22.68"
            fill="none"
            stroke="#f59e0b"
            strokeWidth="16"
            opacity="0.8"
          />
          {/* Green zone (70-100%) */}
          <path
            d="M 126.18 22.68 A 80 80 0 0 1 180 100"
            fill="none"
            stroke="#22c55e"
            strokeWidth="16"
            strokeLinecap="round"
            opacity="0.8"
          />

          {/* Labels — placed outside/below the arc ends and above the top */}
          <text x="10" y="122" fontSize="9" fill="#ef4444" textAnchor="middle" fontFamily="Inter" fontWeight="800">NO</text>
          <text x="100" y="8" fontSize="9" fill="#f59e0b" textAnchor="middle" fontFamily="Inter" fontWeight="800">MAYBE</text>
          <text x="190" y="122" fontSize="9" fill="#22c55e" textAnchor="middle" fontFamily="Inter" fontWeight="800">YES!</text>

          {/* Needle */}
          <motion.g
            initial={{ rotate: -90 }}
            animate={{ rotate: needleAngle }}
            transition={{ type: 'spring', stiffness: 60, damping: 15, delay: 0.3 }}
            style={{ transformOrigin: '100px 100px' }}
          >
            <line
              x1="100"
              y1="100"
              x2="100"
              y2="35"
              stroke="hsl(var(--foreground))"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
            <circle cx="100" cy="100" r="5" fill="hsl(var(--foreground))" />
          </motion.g>

          {/* Center dot overlay */}
          <circle cx="100" cy="100" r="3" fill="hsl(var(--card))" />
        </svg>
      </div>

      {/* Percentage and Label */}
      <div className="text-center -mt-4">
        <p className="text-3xl font-bold text-foreground font-inter">{Math.round(value)}%</p>
        <p className={`text-sm font-semibold ${label.color} mt-1`}>{label.text}</p>
      </div>
    </div>
  );
}