import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { THEORY_CONTENT } from '@/lib/theoryContent';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ChevronDown, ChevronUp, BookOpen, ExternalLink, ChevronRight } from 'lucide-react';
import SubsectionModal from './SubsectionModal';

const DOMAIN_TABS = [
  {
    id: 'people',
    label: 'People',
    activeBg: 'bg-emerald-600',
    gradient: 'from-emerald-500 to-teal-600',
    accent: 'text-emerald-600',
  },
  {
    id: 'process',
    label: 'Process',
    activeBg: 'bg-indigo-600',
    gradient: 'from-indigo-500 to-violet-600',
    accent: 'text-indigo-600',
  },
  {
    id: 'business_environment',
    label: 'Business',
    activeBg: 'bg-amber-600',
    gradient: 'from-amber-500 to-orange-600',
    accent: 'text-amber-600',
  },
];

function SectionRow({ section, activeTab, onSubsectionClick }) {
  const [open, setOpen] = useState(false);
  const tab = DOMAIN_TABS.find(t => t.id === activeTab);

  return (
    <div className="border border-border rounded-xl overflow-hidden mb-2">
      {/* Section header — clickable to expand subsections */}
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-3 p-3 text-left bg-card hover:bg-muted/40 transition-colors"
      >
        <div className={`shrink-0 w-7 h-7 rounded-lg bg-gradient-to-br ${tab.gradient} flex items-center justify-center`}>
          <span className="text-white text-[10px] font-bold">{section.number}</span>
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-foreground text-xs leading-snug">{section.title}</p>
          <p className="text-[10px] text-muted-foreground mt-0.5">{section.subsections.length} subtopics</p>
        </div>
        {open
          ? <ChevronUp className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
          : <ChevronDown className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
        }
      </button>

      {/* Subsections list */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="overflow-hidden"
          >
            <div className="border-t border-border bg-muted/20">
              {section.subsections.map((sub) => (
                <button
                  key={sub.id}
                  onClick={() => onSubsectionClick(sub)}
                  className="w-full flex items-center gap-2 px-3 py-2.5 text-left hover:bg-accent/60 transition-colors border-b border-border/50 last:border-0 group"
                >
                  <span className={`text-[10px] font-bold ${tab.accent} w-8 shrink-0`}>{sub.number}</span>
                  <span className="flex-1 text-xs text-foreground leading-snug">{sub.title}</span>
                  <ChevronRight className="w-3 h-3 text-muted-foreground group-hover:text-primary transition-colors shrink-0" />
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function TheoryLibrary() {
  const [activeTab, setActiveTab] = useState('people');
  const [selectedSubsection, setSelectedSubsection] = useState(null);
  const content = THEORY_CONTENT[activeTab];
  const activeStyle = DOMAIN_TABS.find(t => t.id === activeTab);

  return (
    <>
      <div className="bg-card rounded-2xl border border-border overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-border bg-gradient-to-r from-primary/5 to-violet-500/5">
          <div className="flex items-center gap-2 mb-1">
            <BookOpen className="w-5 h-5 text-primary" />
            <h3 className="font-bold text-foreground font-inter text-base">Knowledge Vault</h3>
            <Badge variant="secondary" className="text-xs">PMBOK 8th Ed.</Badge>
          </div>
          <p className="text-xs text-muted-foreground">
            Click any subtopic to open full-screen reading view
          </p>
        </div>

        {/* Domain Tabs */}
        <div className="flex border-b border-border">
          {DOMAIN_TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-2.5 px-2 text-xs font-semibold transition-all ${
                activeTab === tab.id
                  ? `${tab.activeBg} text-white`
                  : 'text-muted-foreground hover:bg-muted/50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Open full page link */}
        <div className="px-4 py-2 border-b border-border">
          <Link
            to={`/theory/${activeTab}`}
            className="inline-flex items-center gap-1.5 text-xs text-primary font-medium hover:underline"
          >
            <ExternalLink className="w-3 h-3" />
            Open full theory page
          </Link>
        </div>

        {/* Sections with subsections */}
        <ScrollArea className="h-[400px]">
          <div className="p-3">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.15 }}
              >
                <p className="text-[11px] text-muted-foreground mb-3 leading-relaxed px-1">{content.intro}</p>
                {content.sections.map(section => (
                  <SectionRow
                    key={section.id}
                    section={section}
                    activeTab={activeTab}
                    onSubsectionClick={setSelectedSubsection}
                  />
                ))}
              </motion.div>
            </AnimatePresence>
          </div>
        </ScrollArea>
      </div>

      {/* Full-screen modal */}
      {selectedSubsection && (
        <SubsectionModal
          subsection={selectedSubsection}
          domainStyle={activeStyle}
          onClose={() => setSelectedSubsection(null)}
        />
      )}
    </>
  );
}