import React from 'react';

/**
 * Parses a markdown table string into headers + rows arrays.
 */
function parseMarkdownTable(lines) {
  const tableLines = lines.filter(l => l.trim().startsWith('|'));
  if (tableLines.length < 2) return null;

  const parseRow = (line) =>
    line.split('|').slice(1, -1).map(c => c.trim());

  const headers = parseRow(tableLines[0]);
  const rows = tableLines.slice(2).map(parseRow); // skip separator line
  return { headers, rows };
}

/**
 * Returns colour classes based on cell content keywords.
 */
function getCellStyle(text) {
  const t = text.toLowerCase();
  if (t.includes('most preferred') || t.includes('★') || t.includes('win–win') || t.includes('highest') || t.includes('positive'))
    return 'bg-emerald-50 text-emerald-800 font-semibold';
  if (t.includes('rarely') || t.includes('avoid') || t.includes('lose–lose') || t.includes('last resort') || t.includes('very low') || t.includes('negative'))
    return 'bg-red-50 text-red-800';
  if (t.includes('acceptable') || t.includes('use sparingly') || t.includes('moderate') || t.includes('shared'))
    return 'bg-amber-50 text-amber-800';
  if (t.includes('buyer') || t.includes('cppc') || t.includes('cpff'))
    return 'bg-orange-50 text-orange-800';
  if (t.includes('seller') || t.includes('ffp') || t.includes('firm fixed'))
    return 'bg-blue-50 text-blue-800';
  return '';
}

function StyledTable({ headers, rows, gradient }) {
  // pick header bg from gradient
  const headerBg = gradient?.includes('emerald') ? 'bg-emerald-600'
    : gradient?.includes('indigo') ? 'bg-indigo-600'
    : gradient?.includes('amber') ? 'bg-amber-600'
    : 'bg-slate-700';

  return (
    <div className="overflow-x-auto rounded-xl border border-border shadow-sm my-4">
      <table className="w-full text-sm border-collapse">
        <thead>
          <tr className={`${headerBg} text-white`}>
            {headers.map((h, i) => (
              <th key={i} className="px-3 py-2.5 text-left font-semibold text-xs uppercase tracking-wide whitespace-nowrap">
                {h.replace(/\*\*/g, '')}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, ri) => (
            <tr key={ri} className={ri % 2 === 0 ? 'bg-card' : 'bg-muted/30'}>
              {row.map((cell, ci) => {
                const colourClass = ci > 0 ? getCellStyle(cell) : '';
                const isFirst = ci === 0;
                return (
                  <td
                    key={ci}
                    className={`px-3 py-2 border-b border-border text-xs align-top ${isFirst ? 'font-semibold text-foreground' : 'text-muted-foreground'} ${colourClass}`}
                  >
                    <span dangerouslySetInnerHTML={{ __html: formatInline(cell) }} />
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/** Convert **bold** and *italic* inline markdown to HTML */
function formatInline(text) {
  return text
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/★/g, '<span class="text-amber-500">★</span>');
}

function ProcessFlowBlock({ text }) {
  const steps = text.split('►').map(s => s.trim()).filter(Boolean);
  return (
    <div className="flex flex-wrap items-center gap-2 my-4">
      {steps.map((step, i) => (
        <React.Fragment key={i}>
          <div className="bg-primary/10 border border-primary/30 rounded-xl px-3 py-2 text-xs font-semibold text-primary text-center min-w-[90px]">
            {step.replace(/\n/g, ' ')}
          </div>
          {i < steps.length - 1 && (
            <span className="text-primary font-bold text-base">→</span>
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

function RiskSpectrumBlock() {
  const items = [
    { label: 'CPPC', side: 'Buyer', color: 'bg-red-100 border-red-300 text-red-800' },
    { label: 'CPFF', side: 'Buyer', color: 'bg-orange-100 border-orange-300 text-orange-800' },
    { label: 'T&M', side: 'Shared', color: 'bg-amber-100 border-amber-300 text-amber-800' },
    { label: 'FPIF', side: 'Seller', color: 'bg-blue-100 border-blue-300 text-blue-800' },
    { label: 'FFP', side: 'Seller', color: 'bg-emerald-100 border-emerald-300 text-emerald-800' },
  ];
  return (
    <div className="my-4 p-4 bg-muted/40 rounded-xl border border-border">
      <div className="flex justify-between text-xs font-bold mb-3 text-muted-foreground">
        <span>← BUYER BEARS MORE RISK</span>
        <span>SELLER BEARS MORE RISK →</span>
      </div>
      <div className="flex gap-2 justify-between flex-wrap">
        {items.map((item, i) => (
          <div key={i} className={`flex-1 min-w-[52px] rounded-lg border-2 px-2 py-2 text-center ${item.color}`}>
            <p className="font-bold text-sm">{item.label}</p>
            <p className="text-[10px] mt-0.5 opacity-80">{item.side}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function TuckmanDiagram() {
  const stages = [
    { num: '1', label: 'FORMING', color: 'bg-slate-100 border-slate-300 text-slate-700', desc: 'Members meet; high PM dependence' },
    { num: '2', label: 'STORMING', color: 'bg-red-100 border-red-300 text-red-700', desc: 'Conflict & power struggles' },
    { num: '3', label: 'NORMING', color: 'bg-amber-100 border-amber-300 text-amber-700', desc: 'Trust & cohesion build' },
    { num: '4', label: 'PERFORMING', color: 'bg-emerald-100 border-emerald-300 text-emerald-700', desc: 'High-functioning & autonomous' },
    { num: '5', label: 'ADJOURNING', color: 'bg-indigo-100 border-indigo-300 text-indigo-700', desc: 'Project ends; lessons learned' },
  ];
  return (
    <div className="my-4 grid grid-cols-5 gap-2">
      {stages.map((s, i) => (
        <div key={i} className={`rounded-xl border-2 p-2 text-center ${s.color}`}>
          <div className="text-2xl font-black opacity-30">{s.num}</div>
          <div className="text-[10px] font-bold uppercase tracking-wide mt-1">{s.label}</div>
          <div className="text-[9px] mt-1 opacity-70 leading-tight">{s.desc}</div>
        </div>
      ))}
    </div>
  );
}

function EthicsBlock() {
  const values = [
    { title: 'RESPONSIBILITY', color: 'bg-indigo-50 border-indigo-200', titleColor: 'text-indigo-700', icon: '⚖️' },
    { title: 'RESPECT', color: 'bg-emerald-50 border-emerald-200', titleColor: 'text-emerald-700', icon: '🤝' },
    { title: 'FAIRNESS', color: 'bg-amber-50 border-amber-200', titleColor: 'text-amber-700', icon: '⚡' },
    { title: 'HONESTY', color: 'bg-rose-50 border-rose-200', titleColor: 'text-rose-700', icon: '💬' },
  ];
  return (
    <div className="grid grid-cols-2 gap-3 my-4">
      {values.map((v, i) => (
        <div key={i} className={`rounded-xl border-2 p-3 ${v.color}`}>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-lg">{v.icon}</span>
            <span className={`font-bold text-xs uppercase tracking-wide ${v.titleColor}`}>{v.title}</span>
          </div>
        </div>
      ))}
    </div>
  );
}

function SustainabilityBlock() {
  const pillars = [
    { label: 'Environmental', icon: '🌿', color: 'bg-emerald-50 border-emerald-300 text-emerald-800', examples: 'Carbon footprint · Energy · Waste · Biodiversity' },
    { label: 'Social', icon: '👥', color: 'bg-blue-50 border-blue-300 text-blue-800', examples: 'Fair labour · DEI · Community · Safety' },
    { label: 'Economic', icon: '💰', color: 'bg-amber-50 border-amber-300 text-amber-800', examples: 'Lifecycle costs · Equitable benefits · Market impact' },
  ];
  return (
    <div className="grid grid-cols-3 gap-3 my-4">
      {pillars.map((p, i) => (
        <div key={i} className={`rounded-xl border-2 p-3 text-center ${p.color}`}>
          <div className="text-2xl mb-1">{p.icon}</div>
          <div className="font-bold text-xs uppercase tracking-wide">{p.label}</div>
          <div className="text-[10px] mt-1.5 opacity-75 leading-tight">{p.examples}</div>
        </div>
      ))}
    </div>
  );
}

function MasteryBadge({ text, color }) {
  return (
    <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold mr-1 mb-1 ${color}`}>
      {text}
    </span>
  );
}

function ExamTipBox({ text }) {
  return (
    <div className="my-3 flex gap-2 bg-amber-50 border border-amber-300 rounded-xl p-3">
      <span className="text-amber-500 text-base shrink-0">💡</span>
      <p className="text-xs text-amber-900 leading-relaxed" dangerouslySetInnerHTML={{ __html: formatInline(text) }} />
    </div>
  );
}

function WarningBox({ text }) {
  return (
    <div className="my-3 flex gap-2 bg-red-50 border border-red-200 rounded-xl p-3">
      <span className="text-red-500 text-base shrink-0">⚠️</span>
      <p className="text-xs text-red-900 leading-relaxed" dangerouslySetInnerHTML={{ __html: formatInline(text) }} />
    </div>
  );
}

/**
 * Main renderer: splits body into blocks and renders each with rich visuals.
 */
export default function VisualReferenceRenderer({ body, gradient }) {
  if (!body) return null;

  const lines = body.split('\n');
  const blocks = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];

    // Skip empty lines
    if (!line.trim()) { i++; continue; }

    // Detect markdown table block
    if (line.trim().startsWith('|')) {
      const tableLines = [];
      while (i < lines.length && lines[i].trim().startsWith('|')) {
        tableLines.push(lines[i]);
        i++;
      }
      const parsed = parseMarkdownTable(tableLines);
      if (parsed) {
        blocks.push({ type: 'table', data: parsed });
      }
      continue;
    }

    // Process flow line (contains ►)
    if (line.includes('►')) {
      blocks.push({ type: 'flow', text: line });
      i++;
      continue;
    }

    // Risk spectrum
    if (line.includes('BUYER BEARS MORE RISK') || line.includes('CPPC') && line.includes('FFP')) {
      blocks.push({ type: 'riskspectrum' });
      // skip until end of code block
      while (i < lines.length && !lines[i].startsWith('|') && lines[i].trim() !== '') i++;
      continue;
    }

    // Tuckman visual trigger
    if (line.includes('Tuckman') || line.includes('FORMING') && line.includes('STORMING')) {
      blocks.push({ type: 'tuckman' });
      i++;
      continue;
    }

    // Ethics block trigger
    if (line.includes('RESPONSIBILITY') && line.includes('RESPECT')) {
      blocks.push({ type: 'ethics' });
      i++;
      continue;
    }

    // Sustainability pillars trigger
    if (line.includes('THREE PILLARS OF SUSTAINABILITY')) {
      blocks.push({ type: 'sustainability' });
      i++;
      continue;
    }

    // Exam tip / warning blockquote
    if (line.startsWith('>')) {
      const text = line.replace(/^>\s*/, '').replace(/\*\*/g, '');
      if (text.toLowerCase().includes('exam') || text.toLowerCase().includes('pmi') || text.toLowerCase().includes('tip') || text.toLowerCase().includes('rule')) {
        blocks.push({ type: 'examtip', text });
      } else if (text.toLowerCase().includes('trap') || text.toLowerCase().includes('warning') || text.toLowerCase().includes('wrong')) {
        blocks.push({ type: 'warning', text });
      } else {
        blocks.push({ type: 'examtip', text });
      }
      i++;
      continue;
    }

    // Bold heading (section title)
    if (line.startsWith('**') && line.endsWith('**') && !line.includes('|')) {
      blocks.push({ type: 'heading', text: line.replace(/\*\*/g, '') });
      i++;
      continue;
    }

    // Code block (skip rendering as plain text)
    if (line.startsWith('```')) {
      const codeLines = [];
      i++;
      while (i < lines.length && !lines[i].startsWith('```')) {
        codeLines.push(lines[i]);
        i++;
      }
      i++; // skip closing ```
      // Only render if it's a process flow
      const joined = codeLines.join(' ');
      if (joined.includes('►')) {
        blocks.push({ type: 'flow', text: joined });
      }
      continue;
    }

    // List item
    if (line.match(/^[-*]\s/)) {
      const listLines = [];
      while (i < lines.length && lines[i].match(/^[-*]\s/)) {
        listLines.push(lines[i].replace(/^[-*]\s/, ''));
        i++;
      }
      blocks.push({ type: 'list', items: listLines });
      continue;
    }

    // Numbered list
    if (line.match(/^\d+\.\s/)) {
      const listLines = [];
      while (i < lines.length && lines[i].match(/^\d+\.\s/)) {
        listLines.push(lines[i].replace(/^\d+\.\s/, ''));
        i++;
      }
      blocks.push({ type: 'numberedlist', items: listLines });
      continue;
    }

    // Default: paragraph text
    blocks.push({ type: 'paragraph', text: line });
    i++;
  }

  return (
    <div className="space-y-1">
      {blocks.map((block, idx) => {
        switch (block.type) {
          case 'table':
            return <StyledTable key={idx} headers={block.data.headers} rows={block.data.rows} gradient={gradient} />;
          case 'flow':
            return <ProcessFlowBlock key={idx} text={block.text} />;
          case 'riskspectrum':
            return <RiskSpectrumBlock key={idx} />;
          case 'tuckman':
            return <TuckmanDiagram key={idx} />;
          case 'ethics':
            return <EthicsBlock key={idx} />;
          case 'sustainability':
            return <SustainabilityBlock key={idx} />;
          case 'examtip':
            return <ExamTipBox key={idx} text={block.text} />;
          case 'warning':
            return <WarningBox key={idx} text={block.text} />;
          case 'heading':
            return (
              <h3 key={idx} className="font-bold text-sm text-foreground mt-4 mb-1 border-b border-border pb-1">
                {block.text}
              </h3>
            );
          case 'list':
            return (
              <ul key={idx} className="space-y-1 my-2">
                {block.items.map((item, ii) => (
                  <li key={ii} className="flex gap-2 text-xs text-muted-foreground">
                    <span className="text-primary mt-0.5 shrink-0">•</span>
                    <span dangerouslySetInnerHTML={{ __html: formatInline(item) }} />
                  </li>
                ))}
              </ul>
            );
          case 'numberedlist':
            return (
              <ol key={idx} className="space-y-1 my-2">
                {block.items.map((item, ii) => (
                  <li key={ii} className="flex gap-2 text-xs text-muted-foreground">
                    <span className="text-primary font-bold shrink-0">{ii + 1}.</span>
                    <span dangerouslySetInnerHTML={{ __html: formatInline(item) }} />
                  </li>
                ))}
              </ol>
            );
          case 'paragraph':
          default:
            return (
              <p key={idx} className="text-xs text-muted-foreground leading-relaxed"
                dangerouslySetInnerHTML={{ __html: formatInline(block.text) }} />
            );
        }
      })}
    </div>
  );
}