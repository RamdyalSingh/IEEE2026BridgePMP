import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Lightbulb } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import VisualReferenceRenderer from './VisualReferenceRenderer';

function isVisualReference(subsection) {
  // Visual reference subsections have numbers like 1.7.x, 2.11.x, 3.8.x
  const n = subsection?.number || '';
  return n.startsWith('1.7.') || n.startsWith('2.11.') || n.startsWith('3.8.');
}

function RegularContentBody({ body }) {
  return (
    <div className="prose prose-sm max-w-none text-foreground leading-relaxed
      prose-strong:text-foreground prose-p:my-2 prose-ul:my-2 prose-li:my-0.5
      prose-h1:text-foreground prose-h2:text-foreground prose-h3:text-foreground
      prose-blockquote:border-primary prose-blockquote:bg-primary/5 prose-blockquote:rounded-r-lg prose-blockquote:py-1 prose-blockquote:not-italic
      prose-table:border prose-th:bg-muted prose-th:px-3 prose-th:py-2 prose-td:px-3 prose-td:py-2 prose-td:border prose-th:border
      prose-code:bg-muted prose-code:px-1 prose-code:rounded prose-code:text-foreground">
      <ReactMarkdown>{body}</ReactMarkdown>
    </div>
  );
}

export default function SubsectionModal({ subsection, domainStyle, onClose }) {
  if (!subsection) return null;

  const isExamTip = subsection.body.toLowerCase().includes('exam tip') || subsection.body.toLowerCase().includes('pmi exam');
  const useVisualRenderer = isVisualReference(subsection);

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-start justify-center p-4 overflow-y-auto"
        onClick={(e) => e.target === e.currentTarget && onClose()}
      >
        <motion.div
          initial={{ opacity: 0, y: 40, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.97 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          className="bg-card w-full max-w-3xl rounded-2xl shadow-2xl my-8 overflow-hidden"
        >
          {/* Header */}
          <div className={`bg-gradient-to-br ${domainStyle.gradient} p-6 text-white`}>
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-white/70 text-xs font-bold uppercase tracking-widest">{subsection.number}</span>
                <h2 className="text-xl font-bold font-inter mt-1 leading-tight">{subsection.title}</h2>
              </div>
              <button
                onClick={onClose}
                className="shrink-0 w-8 h-8 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors"
              >
                <X className="w-4 h-4 text-white" />
              </button>
            </div>
            {isExamTip && (
              <div className="mt-3 flex items-center gap-2 bg-white/15 rounded-lg px-3 py-1.5">
                <Lightbulb className="w-4 h-4 text-yellow-300 shrink-0" />
                <span className="text-white/90 text-xs font-semibold">Contains PMI Exam Tips</span>
              </div>
            )}
            {useVisualRenderer && (
              <div className="mt-3 flex items-center gap-2 bg-white/15 rounded-lg px-3 py-1.5">
                <span className="text-lg">📊</span>
                <span className="text-white/90 text-xs font-semibold">Visual Reference — Charts, Tables & Cheat Sheets</span>
              </div>
            )}
          </div>

          {/* Content */}
          <div className="p-6 overflow-y-auto max-h-[70vh]">
            {useVisualRenderer
              ? <VisualReferenceRenderer body={subsection.body} gradient={domainStyle.gradient} />
              : <RegularContentBody body={subsection.body} />
            }
          </div>

          {/* Footer */}
          <div className="px-6 py-4 border-t border-border bg-muted/30 flex justify-end">
            <button
              onClick={onClose}
              className={`px-5 py-2 rounded-xl bg-gradient-to-br ${domainStyle.gradient} text-white text-sm font-semibold hover:opacity-90 transition-opacity`}
            >
              Close
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}